#!/usr/bin/env node
'use strict';


require('./lib');
require('./dist');
